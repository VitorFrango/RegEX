

"""Exame Especial de IPRP: Julho 2012."""



# P3 : Regra de horner

def horner(coeficientes, x):
    """ coeficientes = [a_n, ..., a_0]."""
    if len(coeficientes) == 1:
        return coeficientes[0]
    else:
        res = coeficientes[0] * x
        for i in range(1,len(coeficientes)-1):
            res = (res + coeficientes[i]) * x
        return res + coeficientes[-1]
    
    
if __name__ == '__main__':
    coef = [3,2,1]
    print horner(coef,2)
        
    