"""
Exame de Recurso.
2010- 2011
"""


# P3
def poli(polinomio, valor):
    """ Devolve o valor do polinómio no ponto valor."""
    res = 0
    for i in range(len(polinomio) + 1):
        res = res + (valor ** i) * polinomio[i]
    return res
        


# P4

def inter_multi(mc1, mc2):
    """ Intersecção de dois multiconjuntos. Representação: dicionários."""
    mc = {}
    for k in mc1:
        if mc2.has_key(k):
            mc[k] = min(mc1[k],mc2[k])
    return mc


# P5

def descodifica(fich, cod_linhas, cod_colunas):
    """ Descodifica a informação guardada no ficheiro."""
    # ler para uma matriz
    ficheiro = open(fich)
    matriz = [ [int(elem) for elem in linha.split()] for linha in ficheiro.readlines()]
    # reorganiza linhas
    matriz_linhas = matriz[:]
    for ind,lin in enumerate(cod_linhas):
        matriz_linhas[ind] = matriz[lin]
    # reorganiza colunas
    nova_mat = zip(*matriz_linhas)
    matriz_colunas = nova_mat[:]
    for ind,col in enumerate(cod_colunas):
        matriz_colunas[ind] = nova_mat[col]
    resultado = zip(*matriz_colunas)
    res = []
    for linha in resultado:
        for coluna in list(linha):
            res.append(coluna)
    return res
    
        
    

# Quad

def quad_magico(quadrado):
    """ Verifica se estamos peranye um quadrado mÃ¡gico."""
    linhas = quadrado
    colunas = zip(*quadrado)

if __name__ =='__main__':
    """
    lista_num = [4,6,5,3,2,7,1]
    polinomio =[1,4,0,2]
    print poli(polinomio,2)
    mconj_1 = {1:2,2:1,3:2,4:2}
    mconj_2 = {1:3,2:2,4:1}
    print inter_multi(mconj_1,mconj_2)
    """
    print descodifica('dados.txt',[0,2,1],[2,1,0])
    
    