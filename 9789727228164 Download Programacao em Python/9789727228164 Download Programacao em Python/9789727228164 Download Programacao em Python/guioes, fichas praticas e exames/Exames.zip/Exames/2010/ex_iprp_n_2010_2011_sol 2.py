"""
Exame 2010-2011
Época Normal
"""

# P3

def dif(matriz,numero):
    """ 
    Retira a cada elemento da matriz o valor igual ao número. Não podem 
    existir valores negativos.
    """
    for lin in range(len(matriz)):
        for col in range(len(matriz[0])):
            matriz[lin][col] = max(matriz[lin][col] - numero, 0)
    return matriz
        
    
    
    
# P4

def procura_pad(texto, padrao):
    """
    Lista com as posições iniciais de todas as ocorrências
    do padrão no texto.
    """
    #comp = len(padrao)
    lista = []
    pos = texto.find(padrao)
    while pos != -1:
        lista.append(pos)
        pos = texto.find(padrao,pos + 1)
    return lista

# P5

def nomes(fich, dicio):
    """
    Usa um ficheiro para extrair nomes 
    e um dicionário para encontrar nome comleto.
    """
    
    ficheiro = open(fich)
    dados = ficheiro.readlines()
    ficheiro.close()

    lista = []
    
    for elem in dados:
        pos = elem.find('~')
        nome = elem[pos+1:-1]
        if nome in dicio:
            completo = dicio[nome][0]
            lista.append(completo)
    lista.sort()
    return lista

if __name__ == '__main__':
    matriz = [[5,15,0],[9,0,8]]
    print dif(matriz,6)
    texto = 'abcbcabc'
    padrao = 'bc'
    texto_2 = 'aaaa'
    padrao_2 = 'aa'
    print procura_pad(texto_2, padrao_2)
    dic = {'ernesto': ['Ernesto Costa','ernesto@dei.uc.pt'], 'abs':['Anabela Borges','abs@isec.pt'], 'abbott':['Abbott Costello','abbot@nowhere.com']}
    print nomes('p5.txt', dic)
    