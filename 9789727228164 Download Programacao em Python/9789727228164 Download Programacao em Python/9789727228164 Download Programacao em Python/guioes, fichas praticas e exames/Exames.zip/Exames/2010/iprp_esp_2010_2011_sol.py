"""
IPRP
Exame Especial
2010 -2011
20 Julho 2011
"""


# P1

# a) Caracteristicas dos objectos
# b) Como podemos interromper um ciclo
# c) Que categorias de parâmetros

# P2

def duplica(l):
    """ Duplica os elementos de uma lista."""
    return [x for x in l for i in (1,2)]

def multiplica(l,n):
    """ Duplica os elementos de uma lista."""
    return [x for x in l for i in range(n)]
# P3

def permuta(numeros):
    """ Verifica se a sequÃªncia e nÃºmeros Ã© uma permutaÃ§Ã£o."""
    comp = len(numeros)
    compara = range(1,comp+1)
    numeros.sort()
    return numeros == compara


# P4

def add_poli(pol_1, pol_2):
    """ Soma de dois polinomios representados como listas
    dos coeficientes."""
    comp_1 = len(pol_1)
    comp_2 = len(pol_2)
    comp = min(comp_1, comp_2)
    soma = []
    for i in range(comp):
        soma.append(pol_1[i] + pol_2[i])
    if comp_1 < comp_2:
        soma = soma + pol_2[comp:]
    if comp_1 > comp_2:
        soma = soma + pol_1[comp:]
    return soma
        
        
        
# P5

def freq(fich):
    """ Le numeros num ficheiro e cria dicionario de trequencias."""
    f_in = open(fich,'r')
    dados = [int(x) for x in  f_in.read().replace('\n',' ').split()]
    dic = {}
    for elem in dados:
        dic[elem] = dic.get(elem,0) +1
    return dic
    

if __name__ == '__main__':
    #print add_poli([1,2,3],[4,5])
    print freq("dados.txt")