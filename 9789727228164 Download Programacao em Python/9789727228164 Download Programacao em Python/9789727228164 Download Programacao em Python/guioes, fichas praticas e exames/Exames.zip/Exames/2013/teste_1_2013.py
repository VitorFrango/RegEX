""" Teste 1."""
# 1 - TP3

"""
Uma cadeia de caracteres é uma sequência (tem ordem), homogénea (cada elemento é um caracter)
e imutável (não é possível alterar o valor sem alterar a identidade.
"""
# 2 - tp3

import turtle

def rectangulo(lado1,lado2):
    for i in range(4):
        if i%2 == 0:
            turtle.forward(lado1)
        else:
            turtle.forward(lado2)
        turtle.left(90)
    turtle.hideturtle()
    
def rect_cor(posx,posy,lado1,lado2,cor):
    # Atributos
    turtle.penup()
    turtle.goto(posx,posy)
    turtle.pendown()
    turtle.fillcolor(cor)
    turtle.begin_fill()
    for i in range(4):
        if i%2 == 0:
            turtle.forward(lado1)
        else:
            turtle.forward(lado2)
        turtle.left(90)
    turtle.end_fill()
    turtle.hideturtle()
    
    
def flor(num_petalas, posx,posy,lado1,lado2,cor):
    """Desenha uma flor admitindo que as pétalas são rectângulos coloridos."""
    orientacao = turtle.heading()
    for i in range(num_petalas):
        rect_cor(posx,posy,lado1,lado2,cor)
        turtle.right(360/num_petalas)

# 3 - tp3

def igual_a_b(cadeia):
    """
    Numa cadeia em que só poem existir 'a', 'b' e 'c' 
    verifica se o número de 'a's é igual au número de 'b's.
    """
    conta_a = 0
    conta_b = 0
    for car in cadeia:
        if car == 'a':
            conta_a = conta_a + 1
        elif car == 'b':
            conta_b = conta_b + 1
    return conta_a == conta_b

# 1 - TP9



# 2 - tp9

def rect_cor(posx,posy,lado1,lado2,cor):
    # Atributos
    turtle.penup()
    turtle.goto(posx,posy)
    turtle.pendown()
    turtle.fillcolor(cor)
    turtle.begin_fill()
    for i in range(4):
        if i%2 == 0:
            turtle.forward(lado1)
        else:
            turtle.forward(lado2)
        turtle.left(90)
    turtle.end_fill()
    turtle.hideturtle()
    
def cara():
    # cabeça
    rect_cor(0,0,120,120,'white')
    # olhos
    rect_cor(30,85,20,20,'blue')
    rect_cor(70,85,20,20,'blue')
    # nariz
    rect_cor(55,30,10,35,'red')
    # boca
    rect_cor(50,15,20,10,'yellow')
    # orelhas
    rect_cor(-10,60,10,30,'red')
    rect_cor(120,60,10,30,'red')
   
# 3 - tp9

def segue_b_a(cadeia):
    """
    Verifica se numa cadeia com apenas 'a's, 'b's e 'c's
    sempre que há um 'a' aparece logo a seguir um 'b'.
    """
    segue = True
    for i in range(len(cadeia)):
        if cadeia[i] == 'a' and (i < len(cadeia) - 1):
            if cadeia[i+1] != 'b':
                segue = False
    return segue

def hamming(cadeia_1, cadeia_2):
    """Calcula a distância de Hamming de duas cadeias."""
    tamanho_menor = min(len(cadeia_1), len(cadeia_2))
    distancia = 0
    for i in range(tamanho_menor):
        if cadeia_1[i] != cadeia_2[i]:
            distancia = distancia + 1
    tamanho_maior = max(len(cadeia_1), len(cadeia_2))
    distancia = distancia + (tamanho_maior - tamanho_menor)
    return distancia


        


if __name__ == '__main__':
    #rect_cor(0,0,20,50,'red')
    #flor(16,0,0,50,100,'red')
    #print(igual_a_b('aabbccb'))
    #print(hamming('abcdefg', 'acddhijkm'))
    cara()
    turtle.exitonclick()
    