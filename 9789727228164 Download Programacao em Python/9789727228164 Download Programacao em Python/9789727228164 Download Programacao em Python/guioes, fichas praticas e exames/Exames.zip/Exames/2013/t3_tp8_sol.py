"""Teste 3 - TP 8."""

# P 1
"""
Espaço de nomes é o local da memória onde ficam os nomes que foram associados 
a objectos através de instruções no código. Espaço dos objectos é o local onde se encontra
a descrição dos objectos, nomeadamente o seu valor e o seu tipo. A identidade é um atributo
dos objectos e indica o local da memória onde este se encontra. A relação entre ambos é feita 
através da identidade do objecto que é conhecida do nome.
"""

# P 2 : onde estão os erros = 2 ? Que tipo de objectos = listas
def inverte(x):
    res = [] # <-- retira = problema
    for i in range(1,len(x)+1): # <-- range(len(x)) = problema
        res.append(x[-i])
    return res

def inverte_b(x):
    res = [] # <-- retira = problema
    for i in range(len(x)): # <-- range(len(x)) = problema
        res.append(x[-i - 1])
    return res

# P3 : grafo como dicionário 

def caminho_2(grafo, x, y):
    suc_x = grafo[x]
    for vert in suc_x:
        if y in grafo.get(vert):
            return True
    return False

if __name__ == '__main__':
    #print inverte((1,2,3))
    
    grafo = {1: [2,3,4], 2:[4,5], 3:[1,4], 4:[], 5:[2,4]}
    print grafo[:]
    #print caminho_2(grafo, 5,3)