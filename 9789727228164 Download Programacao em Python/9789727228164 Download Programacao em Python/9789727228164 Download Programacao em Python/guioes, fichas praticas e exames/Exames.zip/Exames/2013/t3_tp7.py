"""Teste 3 - TP 7."""

# P 1
"""
Aliasing é  o mecanismo que consiste em associar mais do que um nome ao mesmo objecto.
>>> x = [1,2,3]
>>> y = x

No caso de o objecto ser mutável, a modificação de um dos seus elementos através de
um dos seus nomes, repercute-se para os outros nomes.

>>> x[1] = 'a'
>>> x
[1,'a',3]
>>> y
[1,'a',3]
"""

# P 2 : onde estão os erros? Que tipo de objectos?
# bad
def retira_dup(x):
    for i in range(len(x)): 
        if x[i] in x[i+1:]:
            x[i+1:].remove(x[i])
    return x


# good

def retira_dup_good(x):
    res = []
    for i in range(len(x)):
        if x[i] not in x[i+1:]:
            res.append(x[i])
    return res

# P3 : grafo como dicionário

def percurso(grafo, caminho):
    for ind in range(len(caminho)-1):
        if  caminho[ind+1] not in grafo.get(caminho[ind]):
            return False
    return True

if __name__ == '__main__':
    print retira_dup_more_good([1,2,2,3,1,1,2])
    #print retira_dup_good([1,2,2,3,1,1,2])

    grafo = {1: [2,3,4], 2:[4,5], 3:[1,4], 4:[], 5:[2,4]}
    #print percurso(grafo, [1,2,5,4])