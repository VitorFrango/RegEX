""" Teste 3"""

# TP 3



# P1


"""
>>> def titi(n):
...	n.append([4])
...
>>> x = [1,2,3]
>>> print(titi(x))
None # ?
>>> x
[1, 2, 3, [4]] # ?
"""

# P2
  
import operator   

def classif(campeonato):
    final = []
    for clube, result in campeonato.items():
        pontos = 3 * result[0], result[1]
        final.append((clube, sum(pontos)))
    final.sort(key=operator.itemgetter(1), reverse=True)
    return final

    
# P3
def suspeito_b(ficheiro,palavras):
    f_ent = open(ficheiro, 'r', enconding='utf8')
    pal_ficheito = f_ent.read().replace('\n',' ').strip().split()
    proibidas = []
    for pal in palavras:
        if pal in pal_ficheiro:
            proibidas.append(pal)
    if len(pal_proibidas) >= len(palavras):
        return True
    else:
        return False
    
    
# TP 9

# P1
"""
>>> def toto(n):
...	res = n.append(4)
...	return res
...
>>> n = (5,6,7)
>>> print(toto(n))
Traceback (most recent call last):
  File "/Applications/WingIDE.app/Contents/MacOS/src/debug/tserver/_sandbox.py", line 1, in <module>
    # Used internally for debug sandbox under external interpreter
  File "/Applications/WingIDE.app/Contents/MacOS/src/debug/tserver/_sandbox.py", line 2, in toto
    if __name__ == '__main__':
builtins.AttributeError: 'tuple' object has no attribute 'append'
>>> n
(5, 6, 7)
"""
# P2

def mais_vict(campeonato):
    res = list(campeonato.items())
    max_v = 0
    clubes = []
    for c,r in res:
        if r[0] > max_v:
            max_v = r[0]
            clubes = [c]
        elif r[0] == max_v:
            clubes.append(c)
    return (clubes, max_v)

  
# P3
def spam(ficheiro, mal_pal,limiar):
    f_ent = open(ficheiro, 'r', enconding='utf8')
    palavras = f_ent.read().replace('\n',' ').strip().split()
    dicio = {}
    for pal in palavras:
        if pal in mal_pal:
            dicio[pal] = dicio.setdefault(pal,0) + 1
    num_ocor = sum(list(dicio.values()))
    if num_ocor > limiar:
        return True
    else:
        return False


if __name__ == '__main__':
    campeonato ={'benfica':[3,2,1],'academica':[2,2,2],'porto':[2,4,0],'sporting':[5,0,1]}
    print(classif(campeonato))
    print(mais_vict(campeonato))
    
    