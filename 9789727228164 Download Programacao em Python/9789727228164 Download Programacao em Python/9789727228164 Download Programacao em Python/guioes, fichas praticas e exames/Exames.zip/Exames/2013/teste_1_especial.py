""" Teste #1  - Especial."""

# P1

"""
Todos os objectos têm identidade (o seu enderço na memória), valor (aquilo que o objecto é e sobre o quasl incidem as operações) e tipo (que identifica o conjunto de valores e de operações que podem ser feitas sobre um objecto do tipo).
"""

# P2
import turtle

def triangulo(posx, posy,lado):
    turtle.showturtle()
    turtle.penup()
    turtle.goto(posx,posy)
    turtle.pendown()
    for i in range(3):
        turtle.forward(lado)
        turtle.left(120)
    turtle.hideturtle()
    
def tri_tri(posx,posy,lado):
    turtle.penup()
    turtle.goto(posx,posy)
    turtle.pendown()
    # triangulo 1
    triangulo(turtle.xcor(),turtle.ycor(),lado)
    # triangulo 2
    turtle.setx(turtle.xcor() + lado)
    triangulo(turtle.xcor(),turtle.ycor(),lado)
    # triangulo 3
    turtle.left(120)
    turtle.forward(lado)
    turtle.right(120)
    triangulo(turtle.xcor(),turtle.ycor(),lado)
    
def tri_tri_bis(posx, posy, lado):
    """ Faz desenho do triângulo exterior, seguido do desenho do triângulo interior."""
    # Posiciona
    turtle.showturtle()
    turtle.penup()
    turtle.goto(posx, posy)
    turtle.pendown()
    # Desenha triângulo exterior
    triangulo(turtle.xcor(),turtle.ycor(),lado)
    # Posiciona no meio da base do triângulo maior com a orientação certa
    turtle.penup()
    turtle.setx(turtle.xcor()+lado/2)
    turtle.pendown()   
    turtle.left(60)
    # Desenha triangulo interior
    triangulo(turtle.xcor(),turtle.ycor(), lado/2)
    
                  

# P3

def troca_cad(cadeia,n):
    if len(cadeia) < 2*n:
        print('Impossível')
        return -1
    return cadeia[-n:] + cadeia[n:-n] + cadeia[:n] 


if __name__ == '__main__':
    #print(troca_cad('ernesto',3))
    #tri_tri(0,0,50)
    tri_tri_bis(0,0,100)
    turtle.exitonclick()