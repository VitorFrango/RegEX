def erro(lista):
    for elem in lista:
        lista[elem] += 1
    return lista

def inverte(x):
    res = []
    for i in range(x):
        res = res.append(x[-i])
    return res

def retira_dup(lista):
    for i in range(len(lista)):
        if lista[i] in lista[i+1:]:
            lista[i+1:].remove(lista[i])
    return lista

def filtra(lista):
    aux = []
    for elem in lista:
        if elem <= 0:
            return aux
        else:
            aux.append(elem)
    return aux

def mediana(lista):
    while len(lista) > 2:
        lista.remove(max(lista))
        lista.remove(min(lista))
    if len(lista) == 1:
        return lista[0]
    else:
        return (lista[0] + lista[1]) / 2
    

if __name__ == '__main__':
    #lista = [1,2,3,4]
    #print(inverte(lista))
    lista = [1,2,3,2,3,4,1]
    lista = [1,2,3,4,5,6,7]
    #print(retira_dup(lista))
    #print(mediana(lista))
    lista = [0,1,3,2]
    print(erro(lista))
    