"""Teste final 2013."""

# P1
def intersecta(a,b):
    inter = []
    for elem in a:
        if elem in b:
            inter.append(elem)
    return inter

def uniao(a,b):
    une = a[:]
    for elem in b:
        if elem not in une:
            une.append(elem)
    return une

def jaccard(a,b):
    return len(intersecta(a,b))/ len(uniao(a,b))


# P2

def inverte(dicio):
    novo_dicio = {}
    for ch, val in dicio.items():
        for elem in val:
            novo_dicio[elem] = novo_dicio.get(elem,[]) + [ch]   
    return novo_dicio

def receitas(dicio):
    inv = inverte(dicio)
    lista = []
    for item in inv.items():
        if not lista:
            lista.append(item)
        else:
            if len(item[1]) > len(lista[0][1]):
                lista = [item]
            elif len(item[1]) == len(lista[0][1]):
                lista.append(item)
    return lista

# P 3
def aulas(ficheiro_in, sala, ficheiro_out):
    saida = []
    with open(ficheiro_in) as f_ent:
        for linha in f_ent:
            dados = linha.split()
            if sala == dados[-1]:
                saida.append(dados[:-1])
        saida.sort()
        f_saida = open(ficheiro_out,'w', encoding='utf8') 
        f_saida.write('Horário da Sala '+ sala + '\n')
        for elem in saida:
            f_saida.write(' '.join(elem) + '\n')
        f_saida.close()
    

if __name__ == '__main__':
    conj_1 = [1,2,3,4]
    conj_2 = [4,5,6,1,7]
    #print(jaccard(conj_1, conj_2))
    rec= {'sonhos':['agua','farinha','manteiga', 'ovo','acucar'],'rabanadas':['pao','leite','ovo', 'manteiga','acucar'],'leite creme':['acucar','farinha','ovo','leite']}
    print(receitas(rec))
    #aulas('/Users/ernestojfcosta/tmp/final2013.txt', 'G41', '/Users/ernestojfcosta/tmp/final2013_out.txt')

    
    
    
    
    
        
        
        
        
            
                                  
        