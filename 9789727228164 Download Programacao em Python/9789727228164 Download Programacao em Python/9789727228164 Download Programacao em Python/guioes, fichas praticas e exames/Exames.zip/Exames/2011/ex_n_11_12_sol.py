# -*- encoding: utf-8 -*-

""" Exame Normal 2011-2012."""

# P 1

""" Listas e tuplos são ambos sequências heterogéneas. 
As listas são mutáveis, os tuplos são imutáveis."""

""" Um operador sobrecarregado é aquele que realiza operações diferentes em função do tipo dos operandos.
Exemplo: '+'. Tanto pode somar  números como concatenar cadeias de caracteres."""

# P 2
"""
i = 20
while (i >= 0):
    print "i= ",i
    i = i - 2
    
--->>> 
for j in range(20,-1,-2):
    print "j= ",j
    
"""  

# P 3

def pontos(valores):
    valores.sort()
    contam = valores[1:-1]
    res = sum(contam)/float(len(contam))
    return res

# P4

def media(ficheiro):
    # ler dados
    f_in = open(ficheiro,'r')
    dados = f_in.readlines()
    f_in.close()   
    # passa a lista de lista de números
    for i in range(len(dados)):
        dados[i] = [float(elem) for elem in dados[i][:-1].split()]
    # identifica os máximos
    maximos = [max(elem) for elem in dados]
    # calcula média
    media = sum(maximos) / float(len(maximos))
    return media

def media_b(ficheiro):
    f_in = open(ficheiro,'r')
    linha = f_in.readline()
    maximos = []
    while linha != '':
        linha_num = [float(elem) for elem in linha[:-1].split()]
        maximos.append(max(linha_num))
        linha = f_in.readline()
    f_in.close()
    return sum(maximos)/float(len(maximos))

# P 5
def esparsa(matriz):
    res = {}
    for linha in range(len(matriz)):
        for coluna in range(len(matriz[0])):
            if matriz[linha][coluna] != 0:
                res[(linha,coluna)] = matriz[linha][coluna]
    return res
    
    

    
if __name__ == '__main__':
    print pontos([1,5,8,3,9,4,2,6,7])
    print esparsa([[5,0,0],[9,0,8],[0,0,33]])
    print media_b("dados.txt")
