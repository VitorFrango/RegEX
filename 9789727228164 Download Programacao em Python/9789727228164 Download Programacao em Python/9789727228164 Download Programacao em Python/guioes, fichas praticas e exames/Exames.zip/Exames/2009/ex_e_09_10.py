# Especial

# P 4

def perfeito(n):
    """ testa se n � um n�mero perfeito."""
    div = [1]
    for i in range(2,n/2 + 1):
        if n % i == 0:
            div.append(i)
    print div
    return sum(div) == n

# P 5

def filtra(fich_in, fich_out, peso_ref, altura_ref):
    f_in = open(fich_in,'r')
    f_out = open(fich_out,'w')
    linha = f_in.readline()
    while linha != '':
        nome, altura,peso = linha[:-1].split()
        if (float(altura) > altura_ref) and (float(peso) > peso_ref):
            dados = linha + '\n'
            f_out.write(linha)
        if (float(altura) < altura_ref) and (float(peso) < peso_ref):
            dados = linha + '\n'
            f_out.write(linha)
        linha = f_in.readline()
    f_in.close()
    f_out.close()
    
        
# P 6
from cTurtle import *

def segmento(tartaruga,pos1,pos2):
    """ tra�a um segmento  entre pos 1 e pos2."""
    tartaruga.pu()
    tartaruga.goto(pos1)
    tartaruga.pd()
    tartaruga.goto(pos2)
    
    
def quad(tartaruga,pos,lado1,lado2):
    tartaruga.pu()
    tartaruga.goto(pos)
    tartaruga.pd() 
    
    segmento(tartaruga,(tartaruga.xcor(),tartaruga.ycor()),(tartaruga.xcor() + lado1,tartaruga.ycor()))
    tartaruga.rt(90)
    
    segmento(tartaruga,(tartaruga.xcor(),tartaruga.ycor()),(tartaruga.xcor(),tartaruga.ycor() + lado2))
    tartaruga.rt(90)
    
    segmento(tartaruga,(tartaruga.xcor(),tartaruga.ycor()),(tartaruga.xcor() - lado1,tartaruga.ycor()))
    tartaruga.rt(90)
    
    segmento(tartaruga,(tartaruga.xcor(),tartaruga.ycor()),(tartaruga.xcor(),tartaruga.ycor() - lado2))
    tartaruga.rt(90)
    
def cara(tartaruga):
    """ Desenha cara."""
    cabeca(tartaruga)
    boca(tartaruga)
    olhos(tartaruga)
    orelhas(tartaruga)
    nariz(tartaruga)
    
def cabeca(tartaruga):
    """ Desenha cabe�a."""
    tartaruga.begin_fill()
    tartaruga.pen(fillcolor='orange')
    quad(tartaruga,(-100,-100),200,200)
    tartaruga.end_fill()
    
def boca(tartaruga):
    tartaruga.begin_fill()
    tartaruga.pen(fillcolor='red')
    quad(tartaruga,(-50,-75), 100,25)
    tartaruga.end_fill()
    
    

def olhos(tartaruga):
    tartaruga.begin_fill()
    tartaruga.pen(fillcolor='blue')
    quad(tartaruga,(-75,25), 25,25)
    tartaruga.end_fill()
    tartaruga.begin_fill()
    tartaruga.pen(fillcolor='blue')
    quad(tartaruga,(50,25),25,25)
    tartaruga.end_fill()

    
def orelhas(tartaruga):
    tartaruga.begin_fill()
    tartaruga.pen(fillcolor='black')
    quad(tartaruga, (-110,10), 10,25)
    tartaruga.end_fill()
    tartaruga.begin_fill()
    tartaruga.pen(fillcolor='black')
    quad(tartaruga,(100,10),10,25)
    tartaruga.end_fill()
    
def nariz(tartaruga):
    quad(tartaruga,(-5,-20),10,40)
    
    
if __name__ == '__main__':
    
    tarta = Turtle()
    #quad(tarta,(0,0),50,100)
    cara(tarta)
    tarta.hideturtle()
    tarta.exitOnClick()
    """
    print perfeito(15)
   
    filtra('/tempo/data/pessoas.txt','/tempo/data/p5_esp.txt', 70,1.80)
    """
    