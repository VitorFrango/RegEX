# Exame Recurso 2009 - 2010

# P1 
# -----------------------
# a) Nos objectos mut�veis posso mudar o valor sem alterar a identidade.
# b) Falso. Contra exemplos: os ficheiros n�o podem ser concatenados, n�o existe
# opera��o de fatiamento,cada caracter n�o pode ser acedido de modo directo.

# P2
# ----------------------
"""
>>> x = [] * 4
>>> y = [[] for i in range(4)]
>>> z = [[]] * 4
>>> x
[]
>>> y
[[], [], [], []]
>>> z
[[], [], [], []]
>>> x == y
False
>>> y == z
True
>>> 
"""

# P 3
# ---------------------
def d(x,y):
    """ A dist�ncia entre duas listas de inteiros."""
    soma = 0
    for i in range(len(x)):
        soma = soma + abs(x[i] - y[i])
    return soma

def d_b(x,y):
    return sum([ abs(x[i] - y[i]) for i in range(len(x))])


# P 4
# -----------------------------
from utils import *
#MIN_T = -100

def dic_max_temp(ficheiro):
    """ Do ficheiro ao dicion�rio."""
    f_in = open(ficheiro, 'r')
    dic = {}
    linha = f_in.readline()

    while linha != '':
        cod,num,temp = linha[:-1].split()
        dic[cod] = max(dic.get(cod,-infinity),int(temp))
        linha = f_in.readline()
    f_in.close()
    return dic

def dic_max_temp_b(ficheiro):
    """ Do ficheiro ao dicion�rio."""
    f_in = open(ficheiro, 'r')
    dic = {}
    linha = f_in.readline()

    while linha != '':
        cod,num,temp = linha[:-1].split()
        dic[cod] = max(dic.get(cod,-100),int(temp))
        linha = f_in.readline()
    f_in.close()
    return dic

# P 5
# -------------------------------
from cTurtle import *

def segmento(tartaruga,pos1,pos2):
    """ tra�a um segmento  entre pos 1 e pos2."""
    tartaruga.pu()
    tartaruga.goto(pos1)
    tartaruga.pd()
    tartaruga.goto(pos2)
    
def quad(tartaruga,lado,cor):
    """Desenha Quadrado da cor."""
    tartaruga.begin_fill()
    tartaruga.pen(shown=False, pencolor='black', fillcolor= cor)
    for i in range(4):
        tartaruga.fd(lado)
        tartaruga.rt(90)
    tartaruga.end_fill()
    
    

def tabuleiro(tartaruga,n,lado):
    tartaruga.pu()
    tartaruga.goto(0,0)
    tartaruga.pd()
    
    for l in range(n):
        # reposiciona
        tartaruga.setx(0)
        tartaruga.sety(tartaruga.ycor() + lado)
        # desenha linha
        for c in range(n):
            if (c + l) % 2 == 0:
                quad(tartaruga,lado,'white')
            else:
                quad(tartaruga,lado,'black')
            tartaruga.setx(tartaruga.xcor() + lado)

        

if __name__ == '__main__':
    """
    l1 = [1,2,3]
    l2 = [4,8,12]
    print d(l1,l2)
    print d_b(l2,l1)
    print dic_max_temp('/tempo/data/exame_r.txt')
    """
    tartaruga = Turtle()
    #segmento(tartaruga,(0,0), (100,100))
    #quad(tartaruga, 50, 'black')
    #quad(tartaruga,100,'white')
    tabuleiro(tartaruga,4,20)
    tartaruga.exitOnClick()
    