# Exame Normal

#  P4

def inverte_colunas(matriz):
    """ Inverte as colunas de uma matriz.
    Representa��o como lista de listas.
    """
    res = matriz[:]
    for indice_linha in range(len(res)):
        res[indice_linha] = res[indice_linha][::-1]
    return res

# alternativa

def perfeito(n):
    """ Determina se um n�mero � perfeito. """
    return (sum([num for num in range(1,n) if (n % num) == 0]) == n)
               
# alternativa

def soma_constante(c, vector):
    """ Soma a constante c a cada uma das componentes do vector v."""
    return [ c + elem for elem in vector]

def soma_constante_b(c, vector):
    """ Soma a constante c a cada uma das componentes do vector v."""
    res= []
    for elem in vector:
        res.append(c+elem)
    return res

# ficheiro e dicion�rio

def fich_dic_a(ficheiro):
    """ L� o conte�do do ficheiro e constr�i um dicion�rio 
    com chave um inteiro e valor uma lista com as palavras de
    comprimento igual ao valor da chave.
    """
    f_in = open(ficheiro, 'r')
    lista_pal = f_in.read().split()
    dic = {}
    for palavra in lista_pal:
        comp = len(palavra)
        dic[comp] = dic.get(comp,[]) + [palavra]
    return dic


def fich_dic_b(ficheiro):
    """ L� o conte�do do ficheiro e constr�i um dicion�rio 
    com chave um inteiro e valor uma lista com as palavras de
    comprimento igual ao valor da chave.
    """
    f_in = open(ficheiro, 'r')
    lista_pal = f_in.read().split()
    dic = {}
    especiais = ['\n','.',',','!','?']
    for palavra in lista_pal:
        if palavra[-1] in especiais:
            palavra = palavra[:-1]
        comp = len(palavra)
        if comp:
            dic[comp] = dic.get(comp,[]) + [palavra]
    return dic

def fich_dic_c(ficheiro):
    """ L� o conte�do do ficheiro e constr�i um dicion�rio 
    com chave um inteiro e valor uma lista com as palavras de
    comprimento igual ao valor da chave.
    """
    especiais = ['\n','.',',','!','?']
    f_in = open(ficheiro, 'r')
    lista_pal = f_in.read().split()
    # filtra
    lista_final = []
    for palavra in lista_pal:
        # s�mbolos especiais fora
        if palavra in especiais:
            continue
        elif palavra[-1] in especiais:
            palavra = palavra[:-1]
        # repeti��es fora
        if palavra not in lista_final:
            lista_final.append(palavra)   
    # Constr�i dicion�rio   
    dic = {}
    for palavra in lista_final:
        comp = len(palavra)
        dic[comp] = dic.get(comp,[]) + [palavra]
    return dic


# P6

from cTurtle import *

def tri(tartaruga,lado, inc):
    """ Desenha um tri�ngulo incompleto."""
    for i in range(3):
        tartaruga.fd(lado)
        tartaruga.rt(120)
        lado = lado + inc
        tartaruga.hideturtle()
        
def main():
    tartaruga = Turtle()
    lado = 30
    inc_lado = 10
    head = 0
    for i in range(15):
        tartaruga.setheading(heading() + head)
        tri(tartaruga,lado, inc_lado)
        lado = lado + 3 * inc_lado
        head = head + 8

    tartaruga.exitOnClick()
    
    
# -- cTurtle

def quadrado(lado):
    for i in range(4):
        fd(lado)
        rt(90)
        
def matriz_quad(pos,num, lado):
    # afastamento
    delta = lado/2
    # posi��o inicial
    xcor = pos[0]
    ycor = pos[1]
    
    for i in range(num):
        goto(xcor,ycor)
        for j in range(num):
            # define cor
            # quadrado
            quadrado(lado)
            # posi��o
            xcor = xpos + j *(lado + delta)
        ycor = ypos + i * (lado + delta)


if __name__ == '__main__':
    """
    mat = [[1,2,3],[4,5,6]]
    print inverte_colunas(mat)
    for i in range(1,1000):
        if perfeito(i):
            print i
    print soma_constante(4, [1,2,3])
    """
    print fich_dic_c('/tempo/data/ex_normal.txt')

    #matriz_quad((0,0),3,30)
    
    