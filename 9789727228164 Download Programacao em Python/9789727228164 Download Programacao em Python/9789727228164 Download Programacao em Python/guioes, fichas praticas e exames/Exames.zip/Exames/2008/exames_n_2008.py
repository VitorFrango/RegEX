#!/usr/bin/env python
# -*- encoding: utf-8 -*-
"""
exame_n_2008.py

Created by Ernesto Costa on 2008-12-21.
Copyright (c) 2008 University of Coimbra. All rights reserved.
"""

import sys
import os
#- Problema 4
def flip_y(img):
	return [lin[::-1] for lin in img]

#- Problema 5
def filmes(fich):
	f=open(fich,'r')
	f6=[]
	f12=[]
	f18=[]
	for linha in f:
		linha_r=linha.split()
		valor='Nome: ' + linha_r[0] + '***' + 'Realizador: ' + linha_r[1]
		if linha_r[2]== '6':
			f6.append(valor)
		elif linha_r[2] == '12':
			f12.append(valor)
		else:
			f18.append(valor)
	f.close()
	resultado={6:f6,12:f12,18:f18}
	return resultado


#- Problema 6
# -- um quadrado
def quad(lado,ang):
	seth(heading() +  ang)
	ht()
	for i in range(4):
		fd(lado)
		rt(90)

	
def quad_n(n):
	setx(0)
	sety(0)
	lado=50
	ang= 25
	for i in range(n):
		quad(lado,ang)
		lado = lado + 10
	raw_input()	
	return 'ok'

#-- Versão recursiva

def quadrado(lado):
	for i in range(4):
		fd(lado)
		rt(90)
	ht()


def quad_n_rec(n,lado,ang):
	if n > 0:
		seth(ang)
		quadrado(lado)
		quad_n_rec(n-1,lado+10,25 + ang)

def main():
	print filmes('/tempo/filmes.txt')

if __name__ == '__main__':
	main()

