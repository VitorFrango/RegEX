 #!/usr/bin/env python
# -*- encoding: mac-roman -*-
"""
exame_iprp_n_2008.py

Created by Ernesto Costa on 2007-12-29.
Copyright (c) 2007 University of Coimbra. All rights reserved.
"""

import sys
import os
from random import *

# Pergunta

def exp_e(x,prec):
	"""Calcula a 'e' levantado a x"""
	resant=0
	res=1
	cont=0
	fact=1
	while (res - resant) > prec:
		cont = cont + 1
		fact= fact * cont
		res,resant= res + (x ** cont)/float(fact),res
	return res
	

# pergunta
# transposta de uma matriz
def transp(ll):
	return [[l[i] for l in ll] for i in range(len(ll[0]))]

# Pergunta
# obter um subdicionário controlado por um critério

def sub_dicio(dicio, func):
	return dict([(chave,dicio[chave]) for chave in dicio.keys() if func(dicio[chave])])
	
def maior_igual_10(x):
	return (x >= 10)

class Deque:
	
	# construtores
	def __init__(self):
		self.lista=[]
		
	def push_f(self,item):
		self.lista.append(item)
		
	def push_t(self,item):
		self.lista.insert(0,item)
	
	# destruidores: retira e devolve item
	def pop_f(self):
		return self.lista.pop()
		
	def pop_t(self):
		return self.lista.pop(0)
		
	# teste
	def vazia_d(self):
		return self.lista == []
		
	def len_d(self):
		return len(self.lista)
	
	# impressão	
	def __str__(self):
		return str(self.lista)

# Problema
# dado um ficheiro de texto calcula o número de linhas, palavras e caracteres

def wc(fich):
	n_lin=0
	n_pal=0
	n_car=0
	f=open(fich)
	for linha in f:
		n_lin=n_lin+1
		lpal=linha.replace('\n','').split()
		n_pal=n_pal + len(lpal)
		for pal in lpal:
			n_car=n_car + len(pal)
	return "Linhas= %d\nPalavras= %d\nCaracteres= %d" % (n_lin,n_pal,n_car)
	
# Pergunta
# gerar acrónimos
def acro(frase):
	lpal=frase.upper().split()
	res=''
	for p in lpal:
		res = res + p[0]
	return res
	
def fich_acro(fich):
	f=open(fich)
	for lin in f:
		print acro(lin)
	return 'Fim'
			
# Problema
# ordenamento por buckett sorting: valores entre 0 e 1
def buckett(seq):
	n=len(seq)
	aux=[[] for j in range(len(seq))]
	for i in range(1,n+1):
		aux[int(n*seq[i-1])].append(seq[i-1])
	for m in range(len(seq)):
		aux[m].sort() # ordena no interior
	res=reduce(lambda x,y:x+y,aux) # flatten da lista de listas
	return res		
 		
def anagrams(s):
	# devolve a lista de todos os anagramas da cadeia s
	if s == "":
		return [s]
	else:
		ans = []
		for w in anagrams(s[1:]):
			for pos in range(len(w)+1):
				ans.append(w[:pos]+s[0]+w[pos:])
		return ans
		
def teste(fich):
	x=open(fich,'r')
	#txt=x.readlines()
	#y=x.split()
	print len(x)
	#print y
	return 0
						

if __name__ == '__main__':
	'''print exp_e(3,0.001)
	print transp([[1,2,3,4],[5,6,7,8],[9,10,11,12]])
	d=Deque()
	print d.vazia_d()
	d.push_f('a')
	d.push_t(1)
	d.push_f('b')
	d.push_t(2)
	print d.len_d()
	print d
	d.pop_t()
	print d
	print d.pop_f()
	print d
	print wc('teste.txt')
	print acro('sporting clube portugal')
	print fich_acro('acro.txt')
	seq=[random() for i in range(15)]
	print buckett(seq)'''
	d=dict(ernesto=12, luisa=7,santos=5,marta=19, luis=4,ana=15,daniela=16)
	print d
	print sub_dicio(d,maior_igual_10)
	print d
	print sub_dicio(d,(lambda x: x < 10))
	#teste('teste.txt')
