#!/usr/bin/env python
# -*- encoding: utf-8 -*-
"""
untitled.py

Created by Ernesto Costa on 2008-09-10.
Copyright (c) 2008 University of Coimbra. All rights reserved.
"""

import sys
import os

# Exame IPRP - Época Especial


# Pergunta 8

# Criar uma classe que mantém uma lista ordenada

class ListaOrd(object):
	def __init__(self, seq=None):
		self.lista=[]
		for elem in seq:
			self.insere(elem)
	
	def insere(self,elem):
		indice = 0
		while indice < len(self.lista):
			if self.lista[indice] > elem:
				break
			indice = indice + 1
		self.lista.insert(indice,elem)
	
		
	def comp(self):
		return len(self.lista)
	
	def elimina(self, elem):
		self.lista.remove(elem)
		
	def pertence(self,elem):
		try:
			self.lista.index(elem)
			return True
		except:
			return False
			
	def mostra(self):
		print "Lista Ordenada: %s" % (self.lista)
		
		
	
def main():
	lo=ListaOrd([1,5,3])
	print lo
	lo.mostra()
	lo.insere(4)
	lo.mostra()
	lo.insere(0)
	lo.insere(10)
	lo.mostra()
	print lo.comp()
	print lo.pertence(6)
	
	


if __name__ == '__main__':
	main()

